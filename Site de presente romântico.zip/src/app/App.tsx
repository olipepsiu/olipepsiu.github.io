import { useState } from "react";
import { EggHuntGame } from "./components/EggHuntGame";
import { SecretButton } from "./components/SecretButton";
import { WinnerScreen } from "./components/WinnerScreen";

export default function App() {
  const [gameComplete, setGameComplete] = useState(false);

  return (
    <div className="font-sans">
      {!gameComplete ? (
        <>
          <EggHuntGame onComplete={() => setGameComplete(true)} />
          <SecretButton />
        </>
      ) : (
        <WinnerScreen />
      )}
    </div>
  );
}
