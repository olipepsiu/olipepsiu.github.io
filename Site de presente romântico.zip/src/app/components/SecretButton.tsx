import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Heart, X } from "lucide-react";

export function SecretButton() {
  const [showPopup, setShowPopup] = useState(false);

  return (
    <>
      {/* Secret button - slightly visible but in corner */}
      <motion.button
        className="fixed bottom-4 right-4 w-12 h-12 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full shadow-lg flex items-center justify-center opacity-30 hover:opacity-100 transition-opacity z-50"
        whileHover={{ scale: 1.2, rotate: 360 }}
        transition={{ duration: 0.5 }}
        onClick={() => setShowPopup(true)}
      >
        <Heart size={24} fill="white" className="text-white" />
      </motion.button>

      {/* Popup */}
      <AnimatePresence>
        {showPopup && (
          <motion.div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowPopup(false)}
          >
            <motion.div
              className="bg-white rounded-2xl p-8 max-w-md mx-4 relative shadow-2xl"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              exit={{ scale: 0, rotate: 180 }}
              transition={{ type: "spring", duration: 0.5 }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowPopup(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>

              <div className="text-center">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="mb-4 flex justify-center"
                >
                  <Heart size={64} className="text-red-500" fill="currentColor" />
                </motion.div>
                
                <h2 className="text-3xl font-bold text-rose-600 mb-4">
                  Eii Manu, o Lipe te ama ein
                </h2>
                
                <div className="flex justify-center gap-2 mt-6">
                  {[...Array(5)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{ y: [0, -10, 0] }}
                      transition={{
                        duration: 0.5,
                        repeat: Infinity,
                        delay: i * 0.1,
                      }}
                    >
                      <Heart size={20} className="text-pink-400" fill="currentColor" />
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
