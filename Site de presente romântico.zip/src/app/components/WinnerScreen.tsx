import { useEffect } from "react";
import { motion } from "motion/react";
import confetti from "canvas-confetti";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function WinnerScreen() {
  useEffect(() => {
    // Confetti explosion
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 100 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function () {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
        colors: ["#FFD700", "#FF6347", "#32CD32", "#FF69B4"],
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
        colors: ["#FFD700", "#FF6347", "#32CD32", "#FF69B4"],
      });
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-amber-50 via-orange-50 to-red-50">
      {/* Mexican pattern decorations */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-32 bg-repeat-x" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l5 15h16l-13 10 5 15-13-10-13 10 5-15-13-10h16z' fill='%23ff6b35'/%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center h-full p-8">
        {/* Winner announcement */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", duration: 1 }}
          className="text-center mb-8"
        >
          <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-orange-500 to-yellow-500 mb-4">
            ¡Felicidades!
          </h1>
          <p className="text-3xl text-orange-700 font-semibold">
            Você encontrou todos os tesouros!
          </p>
        </motion.div>

        {/* Vale card */}
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, type: "spring" }}
          className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-3xl shadow-2xl p-8 max-w-2xl w-full border-8 border-amber-400"
        >
          {/* Decorative corners */}
          <div className="absolute top-0 left-0 w-16 h-16 border-t-4 border-l-4 border-red-500 rounded-tl-3xl" />
          <div className="absolute top-0 right-0 w-16 h-16 border-t-4 border-r-4 border-red-500 rounded-tr-3xl" />
          <div className="absolute bottom-0 left-0 w-16 h-16 border-b-4 border-l-4 border-red-500 rounded-bl-3xl" />
          <div className="absolute bottom-0 right-0 w-16 h-16 border-b-4 border-r-4 border-red-500 rounded-br-3xl" />

          <div className="relative text-center">
            <motion.div
              animate={{ rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="mb-6"
            >
              <span className="text-8xl">🌮</span>
            </motion.div>

            <h2 className="text-5xl font-bold text-red-600 mb-4">
              VALE GUACAMOLE
            </h2>

            <div className="bg-white/70 rounded-xl p-6 mb-6">
              <p className="text-2xl text-orange-800 font-semibold mb-2">
                Seu presente especial:
              </p>
              <p className="text-xl text-orange-700">
                Uma noite deliciosa no restaurante Guacamole! 🎉
              </p>
            </div>

            <div className="flex justify-center gap-4 mb-6">
              <span className="text-4xl animate-bounce">🌶️</span>
              <span className="text-4xl animate-bounce" style={{ animationDelay: "0.1s" }}>🥑</span>
              <span className="text-4xl animate-bounce" style={{ animationDelay: "0.2s" }}>🌯</span>
              <span className="text-4xl animate-bounce" style={{ animationDelay: "0.3s" }}>🌮</span>
              <span className="text-4xl animate-bounce" style={{ animationDelay: "0.4s" }}>🎊</span>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="relative h-48 rounded-xl overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1759265231461-75abc2f1edc1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZXhpY2FuJTIwcmVzdGF1cmFudCUyMGNvbG9yZnVsJTIwZmVzdGl2ZXxlbnwxfHx8fDE3NzQ2NTI5MzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Mexican restaurant"
                  className="w-full h-full object-cover"
                  width={400}
                  height={300}
                />
              </div>
              <div className="relative h-48 rounded-xl overflow-hidden">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1618215701925-100abf073bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxndWFjYW1vbGUlMjB0YWNvcyUyMHZpYnJhbnR8ZW58MXx8fHwxNzc0NjUyOTMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Guacamole and tacos"
                  className="w-full h-full object-cover"
                  width={400}
                  height={300}
                />
              </div>
            </div>

            <div className="bg-red-100 rounded-xl p-4 border-2 border-red-300">
              <p className="text-lg text-red-700 italic">
                "Da Manu, com todo amor do Lipe ❤️"
              </p>
              <p className="text-sm text-red-600 mt-2">
                Prepare-se para uma experiência mexicana inesquecível!
              </p>
            </div>
          </div>
        </motion.div>

        {/* Footer message */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-8 text-2xl text-orange-700 font-semibold"
        >
          Te amo muito, Manu! 💕
        </motion.p>
      </div>
    </div>
  );
}
