import { useState } from "react";
import { motion } from "motion/react";
import { Heart, Sparkles } from "lucide-react";

interface EggHuntGameProps {
  onComplete: () => void;
}

const eggs = [
  { id: 1, left: "15%", top: "20%", color: "#FFB6C1" },
  { id: 2, left: "70%", top: "15%", color: "#FFE4E1" },
  { id: 3, left: "45%", top: "60%", color: "#FFC0CB" },
  { id: 4, left: "80%", top: "70%", color: "#FFB6C1" },
  { id: 5, left: "25%", top: "75%", color: "#FFE4E1" },
];

const loveMessages = [
  "Te amo ❤️",
  "Você é especial",
  "Meu amor",
  "Meu presente pra você",
  "Com carinho",
  "Para minha Manu",
];

export function EggHuntGame({ onComplete }: EggHuntGameProps) {
  const [foundEggs, setFoundEggs] = useState<number[]>([]);
  const [hearts, setHearts] = useState<{ id: number; x: number; y: number }[]>([]);

  const handleEggClick = (eggId: number, event: React.MouseEvent) => {
    if (!foundEggs.includes(eggId)) {
      setFoundEggs([...foundEggs, eggId]);
      
      // Adiciona corações flutuantes no local do clique
      const rect = (event.target as HTMLElement).getBoundingClientRect();
      const newHearts = Array.from({ length: 5 }, (_, i) => ({
        id: Date.now() + i,
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      }));
      setHearts([...hearts, ...newHearts]);
      
      // Remove corações após animação
      setTimeout(() => {
        setHearts(prev => prev.filter(h => !newHearts.some(nh => nh.id === h.id)));
      }, 1000);

      // Checa se encontrou todos
      if (foundEggs.length + 1 === eggs.length) {
        setTimeout(onComplete, 800);
      }
    }
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-pink-50 via-white to-red-50">
      {/* Floating hearts background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-pink-300 opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-20, 20, -20],
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: Math.random() * 2,
            }}
          >
            <Heart size={24 + Math.random() * 16} fill="currentColor" />
          </motion.div>
        ))}
      </div>

      {/* Love messages scattered around */}
      {loveMessages.map((message, i) => (
        <motion.div
          key={i}
          className="absolute text-pink-500 font-handwriting opacity-60 pointer-events-none"
          style={{
            left: `${10 + Math.random() * 80}%`,
            top: `${10 + Math.random() * 80}%`,
            fontSize: `${16 + Math.random() * 8}px`,
            transform: `rotate(${-15 + Math.random() * 30}deg)`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.6, scale: 1 }}
          transition={{ delay: i * 0.2 }}
        >
          {message}
        </motion.div>
      ))}

      {/* Title */}
      <motion.div
        className="absolute top-8 left-1/2 -translate-x-1/2 text-center z-10"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-4xl font-bold text-rose-600 mb-2">
          O presente secreto da Manuzinha
        </h1>
        <p className="text-xl text-rose-500">(meu amor)</p>
      </motion.div>

      {/* Instructions */}
      <motion.div
        className="absolute top-32 left-1/2 -translate-x-1/2 text-center bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5 }}
      >
        <p className="text-rose-600 flex items-center gap-2">
          <Sparkles size={20} />
          <span>Encontre os {eggs.length} tesouros escondidos para descobrir seu presente!</span>
          <Sparkles size={20} />
        </p>
        <p className="text-sm text-rose-500 mt-1">
          {foundEggs.length} de {eggs.length} encontrados
        </p>
      </motion.div>

      {/* Hidden eggs */}
      {eggs.map((egg) => (
        <motion.button
          key={egg.id}
          className={`absolute w-12 h-14 rounded-full transition-all ${
            foundEggs.includes(egg.id) ? "opacity-0 scale-0" : "opacity-70 hover:opacity-100 hover:scale-110"
          }`}
          style={{
            left: egg.left,
            top: egg.top,
            background: `linear-gradient(135deg, ${egg.color} 0%, #fff 50%, ${egg.color} 100%)`,
            boxShadow: foundEggs.includes(egg.id) ? "none" : "0 4px 12px rgba(255, 105, 180, 0.3)",
          }}
          onClick={(e) => handleEggClick(egg.id, e)}
          whileHover={{ rotate: [0, -10, 10, 0] }}
          transition={{ duration: 0.3 }}
        />
      ))}

      {/* Animated hearts on click */}
      {hearts.map((heart) => (
        <motion.div
          key={heart.id}
          className="absolute text-red-500 pointer-events-none"
          style={{ left: heart.x, top: heart.y }}
          initial={{ scale: 0, opacity: 1 }}
          animate={{
            scale: 1.5,
            opacity: 0,
            y: -100,
            x: (Math.random() - 0.5) * 100,
          }}
          transition={{ duration: 1 }}
        >
          <Heart size={24} fill="currentColor" />
        </motion.div>
      ))}

      {/* Progress indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {eggs.map((egg) => (
          <motion.div
            key={egg.id}
            className={`w-3 h-3 rounded-full ${
              foundEggs.includes(egg.id) ? "bg-rose-500" : "bg-rose-200"
            }`}
            animate={foundEggs.includes(egg.id) ? { scale: [1, 1.5, 1] } : {}}
          />
        ))}
      </div>
    </div>
  );
}
